package calculator;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

/**
 * class for unit test the method squareRootOf using assertEquals.
 * @author mahysalama
 * @version 1.0
 */
public class SquareRootOfTest {

	@Test
	public void test() {
		   assertEquals(0.447213595499958, F7Functions.squareRootOf(0.2));
	}

}
