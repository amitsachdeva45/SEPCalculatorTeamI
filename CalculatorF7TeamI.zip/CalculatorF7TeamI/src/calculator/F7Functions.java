package calculator;


/**
 * class includes all functions invoked while calculating F7 = a^b^x.
 * 
 * @author mahysalama
 * @version 1.0
 */


public class F7Functions {
  /**
   * Method to determine if a number has a fractional part or not.
   * 
   * @param number of type double.
   * @return boolean.
   */
  public static boolean isDecimal(double number) {
    return number % 1 != 0;
  }

  /**
   * Method to determine the absolute value of a number.
   * 
   * @param number of type double.
   * @return double.
   */
  public static double absoluteValueOf(double number) {
    if (number < 0)
      return (number * -1);
    else
      return number;
  }

  /**
   * Method to determine the square root of a number.
   * 
   * @param number of type double.
   * @return double.
   */
  public static double squareRootOf(double number) {
    double oldValue = 0;
    double estimate = number / 2;
    while (absoluteValueOf(estimate - oldValue) > 1e-15) {
      oldValue = estimate;
      estimate = (number / estimate + estimate) / 2;
    }
    return estimate;
  }

  /**
   * Method used when the base is not 0 and the exponent is decimal for the F7= a^b^x using binary
   * search. Using math rule where a^b * a^c = a^(b+c), we first decompose decimal exponent into
   * integer part and fractional part.
   * 
   * @param base of type double, exponent of type double.
   * @return double.
   */

  public static double decimalPowerOf(double base, double exponent) {
    // Extract the integer part of the exponent
    int integerPart = (int) exponent;
    // Extract the fractional part of the exponent
    double fractionalPart = exponent - integerPart;
    double minValue = 0;
    double maxValue = 1;
    double midValue = (minValue + maxValue) / 2;
    double temp = squareRootOf(base);

    double result_1 = powerOf(base, integerPart);
    double result_2 = temp;

    // Binary search where we keep dividing by 2 until you get as close as possible to the target
    // value.
    while (absoluteValueOf(midValue - fractionalPart) > 1e-15) {
      temp = squareRootOf(temp);
      if (midValue > fractionalPart) {
        maxValue = midValue;
        result_2 /= temp;
      } else {
        minValue = midValue;
        result_2 *= temp;
      }
      midValue = (minValue + maxValue) / 2;
    }
    // Using math rule mentioned earlier, multiply previous two results.
    return result_1 * result_2;
  }

  /**
   * Method used when the base is 0 or the exponent is not decimal for the F7= a^b^x.
   * 
   * @param base of type double, exponent of type double.
   * @return double.
   */

  public static double powerOf(double base, double exponent) {
    double result = 1;
    boolean isExponentDecimal = isDecimal(exponent);

    if (isExponentDecimal == false)
      for (double i = 0; i < absoluteValueOf(exponent); i++)
        result *= base;
    else if (base == 0)
      result = 0;
    else
      result = decimalPowerOf(base, absoluteValueOf(exponent));

    // When the exponent is negative, take the reciprocal of previous result.
    result = (exponent < 0) ? 1 / result : result;
    return result;
  }

  /**
   * Method used to compute F7 = a^b^x.
   * 
   * @param a of type double, b of type double and x of type double.
   * @return double.
   */
  public static double function7(double a, double b, double x) {

    return powerOf(a, powerOf(b, x));


  }



}
