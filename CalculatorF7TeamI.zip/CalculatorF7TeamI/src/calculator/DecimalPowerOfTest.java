package calculator;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

/**
 * class for unit test the method decimalPowerOf using assertEquals.
 * @author mahysalama
 * @version 1.0
 */

public class DecimalPowerOfTest {

	@Test
	public void test() {
		   assertEquals(0.23492378861760357, F7Functions.decimalPowerOf(0.2,0.9));
	}

}
