package calculator;


/**
 * An exception class to be used in case the user inputs a negative base number 
 * and a decimal exponent number when testing the F7 = a^b^x function.
 * @author mahysalama
 * @version 1.0
 */
public class ExponentiationException extends Exception {

  private static final long serialVersionUID = 1L;

	public ExponentiationException () {
		super("Error: Base cannot be negative while exponent is decimal.");
	}

	public ExponentiationException (String message) {
		super(message);
	}
}