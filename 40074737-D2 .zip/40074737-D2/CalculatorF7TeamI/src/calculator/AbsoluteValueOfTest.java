package calculator;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

/**
 * class for unit test the method absoluteValueOf using assertEquals.
 * @author mahysalama
 * @version 1.0
 */

public class AbsoluteValueOfTest {

	@Test
	public void test() {
		   assertEquals(0.2, F7Functions.absoluteValueOf(-0.2));
	}

}
