package calculator;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * class driver has the main function that interact with the user for calculating F7= a^b^x.
 * 
 * @author mahysalama
 * @version 1.0
 */
public class F7main {

  /**
   * main function that interact with the user for calculating F7= a^b^x.
   */
  public static void main(String[] args) {

    Scanner scan = new Scanner(System.in);
    double a = 0;
    double b = 0;
    double x = 0;
    String decision1 = "";
    String decision2 = "";
    String decision3 = "";

    boolean flag = true;
    boolean flag2 = true;
    System.out.println("***********************************************************************");
    System.out.println("                   Welcome to our Function F7= a^b^x                   ");
    System.out.println("    a and b will remain constants with you, while x can be changed.    ");
    System.out.println("***********************************************************************");

    while (flag == true && flag2 == true) {
      try {
        System.out.println("Please enter real number for a:");
        a = scan.nextDouble();
        System.out.println("Please enter real number for b:");
        b = scan.nextDouble();
        flag = false;
      }

      catch (InputMismatchException e) {
        System.err.println("Error: Entered value should not be anything else than a real number.");
        scan.nextLine();

        while (true) {

          System.out.println("\nWould you like to continue in our function (Y/N)? ");
          decision1 = scan.next();
          if (decision1.length() == 1
              && (decision1.charAt(0) == 'Y' || decision1.charAt(0) == 'y')) {
            break;
          } else if (decision1.length() == 1
              && (decision1.charAt(0) == 'N' || decision1.charAt(0) == 'n')) {
            System.out.println("*******************************************");
            System.out.println("      Thanks and see you next time         ");
            System.out.println("*******************************************");
            scan.close();
            System.exit(0);
          } else {
            System.err.println("Error: Entered value does not correspond to Y or N. Please retry.");
            scan.nextLine();
            continue;
          }
        }
      }

      while (flag2 == true && flag == false) {
        try {
          System.out.println("Please enter real number for x: ");
          x = scan.nextDouble();
          // flag2 = false;

          if ((b < 0) && F7Functions.isDecimal(x)) {
            throw new ExponentiationException();
          }
          if ((a < 0) && F7Functions.isDecimal(F7Functions.powerOf(b, x))) {
            throw new ExponentiationException();
          }
          if ((b == 0) && x < 0) {
            throw new InfinityException();
          }

          System.out.println(
              "The value of " + a + "^" + b + "^" + x + " is " + F7Functions.function7(a, b, x));

          while (true) {
            System.out.print("\nWould you like to continue with other values for x (Y/N)? ");
            decision2 = scan.next();
            if (decision2.length() == 1
                && (decision2.charAt(0) == 'Y' || decision2.charAt(0) == 'y')) {
              flag2 = true;
              break;
            } else if (decision2.length() == 1
                && (decision2.charAt(0) == 'N' || decision2.charAt(0) == 'n')) {
              System.out.println("*******************************************");
              System.out.println("      Thanks and see you next time         ");
              System.out.println("*******************************************");
              scan.close();
              System.exit(0);
            } else {
              System.err
                  .println("Error: Entered value does not correspond to Y or N. Please retry.");
              scan.nextLine();
              continue;
            }
          }
        }

        catch (InputMismatchException e) {
          System.err
              .println("Error: Entered value should not be anything else than a real number.");
          scan.nextLine();

          while (true) {

            System.out.println("\nWould you like to continue in our function (Y/N)? ");
            decision1 = scan.next();
            if (decision1.length() == 1
                && (decision1.charAt(0) == 'Y' || decision1.charAt(0) == 'y')) {
              break;
            } else if (decision1.length() == 1
                && (decision1.charAt(0) == 'N' || decision1.charAt(0) == 'n')) {
              System.out.println("*******************************************");
              System.out.println("      Thanks and see you next time         ");
              System.out.println("*******************************************");
              scan.close();
              System.exit(0);
            } else {
              System.err
                  .println("Error: Entered value does not correspond to Y or N. Please retry.");
              scan.nextLine();
              continue;
            }
          }

        } catch (ExponentiationException e) {
          System.err.println(e.getMessage());
          scan.nextLine();

          while (true) {

            System.out.println("\nWould you like to continue in our function (Y/N)? ");
            decision3 = scan.next();
            if (decision3.length() == 1
                && (decision3.charAt(0) == 'Y' || decision3.charAt(0) == 'y')) {
              flag = true;
              flag2 = true;
              break;
            } else if (decision3.length() == 1
                && (decision3.charAt(0) == 'N' || decision3.charAt(0) == 'n')) {
              System.out.println("*******************************************");
              System.out.println("                 Thanks                    ");
              System.out.println("*******************************************");
              scan.close();
              System.exit(0);
            } else {
              System.err
                  .println("Error: Entered value does not correspond to Y or N. Please retry.");
              scan.nextLine();
              continue;
            }
          }
        } catch (InfinityException e) {
          System.err.println(e.getMessage());
          scan.nextLine();

          while (true) {

            System.out.println("\nWould you like to continue in our function (Y/N)? ");
            decision3 = scan.next();
            if (decision3.length() == 1
                && (decision3.charAt(0) == 'Y' || decision3.charAt(0) == 'y')) {
              flag = true;
              flag2 = true;
              break;
            } else if (decision3.length() == 1
                && (decision3.charAt(0) == 'N' || decision3.charAt(0) == 'n')) {
              System.out.println("*******************************************");
              System.out.println("                 Thanks                    ");
              System.out.println("*******************************************");
              scan.close();
              System.exit(0);
            } else {
              System.err
                  .println("Error: Entered value does not correspond to Y or N. Please retry.");
              scan.nextLine();
              continue;
            }
          }
        }
      }
    }
  }
}
