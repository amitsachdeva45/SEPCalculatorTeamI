package calculator;
// An exception class to be used in case the user inputs a negative number when testing the square root function.

public class SquareRootException extends Exception {

	private static final long serialVersionUID = 1L;

	public SquareRootException () {
		super("Error: Cannot compute the square root of a negative number.");
	}

	public SquareRootException (String message) {
		super(message);
	}
}