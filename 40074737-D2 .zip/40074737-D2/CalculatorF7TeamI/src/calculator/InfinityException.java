
	package calculator;


	/**
	 * An exception class to be used in case the user inputs a negative base number 
	 * and a decimal exponent number when testing the F7 = a^b^x function.
	 * @author mahysalama
	 * @version 1.0
	 */
	public class InfinityException extends Exception {

	  private static final long serialVersionUID = 1L;

		public InfinityException () {
			super("Error: b = 0 and x negative, gives infinity, and a cannot be raized to the power infinity.");
		}

		public InfinityException (String message) {
			super(message);
		}
	}

