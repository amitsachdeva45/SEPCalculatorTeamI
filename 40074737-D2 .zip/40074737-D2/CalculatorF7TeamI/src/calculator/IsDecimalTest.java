package calculator;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

/**
 * class for unit test the method isDecimal using assertEquals.
 * @author mahysalama
 * @version 1.0
 */
public class IsDecimalTest {

	@Test
	public void test() {
		   assertEquals(true, F7Functions.isDecimal(-0.2));
	}

}
