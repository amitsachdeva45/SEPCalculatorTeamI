package calculator;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
/**
 * class for unit test the method function7 using assertEquals.
 * @author mahysalama
 * @version 1.0
 */

public class Function7Test {

  @Test
  public void test() {
		   assertEquals(0.04008931483092967, F7Functions.function7(0.2,0.5, -0.999));
	}

}
