package calculator;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

/**
 * class for unit test the method powerOf using assertEquals.
 * @author mahysalama
 * @version 1.0
 */
public class PowerOfTest {

	@Test
	public void test() {
		   assertEquals(0.447213595499958, F7Functions.powerOf(0.2,0.5));
	}

}
