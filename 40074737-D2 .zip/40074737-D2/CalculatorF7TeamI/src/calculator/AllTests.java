package calculator;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({AbsoluteValueOfTest.class, DecimalPowerOfTest.class, Function7Test.class,
    IsDecimalTest.class, PowerOfTest.class, SquareRootOfTest.class})
public class AllTests {

}

